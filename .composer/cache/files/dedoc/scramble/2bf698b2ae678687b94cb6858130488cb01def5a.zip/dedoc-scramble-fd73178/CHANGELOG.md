# Changelog

All notable changes to `scramble` will be documented in this file.
