<?php

namespace Dedoc\Scramble\Support\Type\Contracts;

interface LiteralType
{
    public function getValue(): mixed;
}
