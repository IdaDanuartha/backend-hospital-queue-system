<?php

namespace Dedoc\Scramble\Support\Generator\Types;

class UnknownType extends StringType {}
