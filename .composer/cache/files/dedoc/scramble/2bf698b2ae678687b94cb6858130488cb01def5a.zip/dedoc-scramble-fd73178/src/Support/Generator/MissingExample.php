<?php

namespace Dedoc\Scramble\Support\Generator;

/**
 * @deprecated Use MissingValue instead
 */
class MissingExample extends MissingValue {}
